﻿<BSPagination>
    <BSPaginationItem IsDisabled="true">Previous</BSPaginationItem>
    <BSPaginationItem Url="javascript:void(0);">1</BSPaginationItem>
    <BSPaginationItem Url="javascript:void(0);">2</BSPaginationItem>
    <BSPaginationItem Url="javascript:void(0);" IsActive="true">3</BSPaginationItem>
    <BSPaginationItem>Plain Text</BSPaginationItem>
    <BSPaginationItem Url="javascript:void(0);">Next</BSPaginationItem>
</BSPagination>