﻿<BSBadge Color="BSColor.Primary" IsPill="true">Primary</BSBadge>
<BSBadge Color="BSColor.Secondary" IsPill="true">Secondary</BSBadge>
<BSBadge Color="BSColor.Success" IsPill="true">Success</BSBadge>
<BSBadge Color="BSColor.Danger" IsPill="true">Danger</BSBadge>
<BSBadge Color="BSColor.Warning" IsPill="true" Class="text-dark">Warning</BSBadge>
<BSBadge Color="BSColor.Info" IsPill="true" Class="text-dark">Info</BSBadge>
<BSBadge Color="BSColor.Light" IsPill="true" Class="text-dark">Light</BSBadge>
<BSBadge Color="BSColor.Dark" IsPill="true">Dark</BSBadge>