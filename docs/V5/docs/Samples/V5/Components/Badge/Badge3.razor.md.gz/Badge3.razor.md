﻿<BSButton Color="BSColor.Primary" Class="position-relative">
    Inbox <BSBadge Color="BSColor.Danger" IsPill="true" Class="position-absolute top-0 start-100 translate-middle">99+</BSBadge>
</BSButton>