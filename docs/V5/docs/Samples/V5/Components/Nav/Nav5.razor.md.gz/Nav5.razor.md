﻿<BSNav IsVertical="true">
    <BSNavItem Url="javascript:void(0);" IsActive="true">Active</BSNavItem>
    <BSNavItem Url="javascript:void(0);">Link</BSNavItem>
    <BSNavItem Url="javascript:void(0);">Link</BSNavItem>
    <BSNavItem Url="javascript:void(0);" IsDisabled="true">Disabled</BSNavItem>
</BSNav>