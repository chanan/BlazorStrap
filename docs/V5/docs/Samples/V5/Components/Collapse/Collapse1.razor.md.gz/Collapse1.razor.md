﻿<BSLink Target="collapse1" MarginEnd="Margins.Medium">Toggle Link</BSLink>
<BSButton Color="BSColor.Primary" Target="collapse1">Toggle Button</BSButton>
<BSCollapse DataId="collapse1">
    <BSCard CardType="CardType.Card">
        Some placeholder content for the collapse component. This panel is hidden by default but revealed when the user activates the relevant trigger.
    </BSCard>
</BSCollapse>