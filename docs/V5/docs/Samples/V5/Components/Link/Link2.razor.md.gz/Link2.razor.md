﻿<BSLink href="javascript:void(0)" IsButton="true" Color="BSColor.Primary" IsOutlined="true">Primary</BSLink>
<BSLink href="javascript:void(0)" IsButton="true" Color="BSColor.Secondary" IsOutlined="true">Primary</BSLink>
<BSLink href="javascript:void(0)" IsButton="true" Color="BSColor.Success" IsOutlined="true">Success</BSLink>
<BSLink href="javascript:void(0)" IsButton="true" Color="BSColor.Danger" IsOutlined="true">Danger</BSLink>
<BSLink href="javascript:void(0)" IsButton="true" Color="BSColor.Warning" IsOutlined="true">Warning</BSLink>
<BSLink href="javascript:void(0)" IsButton="true" Color="BSColor.Info" IsOutlined="true">Info</BSLink>
<BSLink href="javascript:void(0)" IsButton="true" Color="BSColor.Light" IsOutlined="true">Light</BSLink>
<BSLink href="javascript:void(0)" IsButton="true" Color="BSColor.Dark" IsOutlined="true">Dark</BSLink>
<BSLink href="javascript:void(0)">Normal Link</BSLink>