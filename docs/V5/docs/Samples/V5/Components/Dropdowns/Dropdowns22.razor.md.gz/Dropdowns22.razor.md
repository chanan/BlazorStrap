<BSDropdown Demo="true" Class="p-4 text-muted" style="max-width: 200px;">
    <Content>
        <p>
           Some example text that's free-flowing within the dropdown menu.
         </p>
         <p class="mb-0">
           And this is more example text.
         </p>
    </Content>
</BSDropdown>