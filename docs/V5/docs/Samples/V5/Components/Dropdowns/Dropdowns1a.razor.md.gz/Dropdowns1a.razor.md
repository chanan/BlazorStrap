﻿<BSDropdown IsMouseover="true">
    <Toggler><BSToggle IsButton="true" Color="BSColor.Secondary">Dropdown button</BSToggle></Toggler>
    <Content>
        <BSDropdownItem>Action</BSDropdownItem>
        <BSDropdownItem>Another action</BSDropdownItem>
        <BSDropdownItem>Something else here</BSDropdownItem>
    </Content>
</BSDropdown>