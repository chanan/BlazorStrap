<BSDropdown Demo="true">
    <Content>
        <BSDropdownItem>Regular link</BSDropdownItem>
        <BSDropdownItem IsActive="true">Active link</BSDropdownItem>
        <BSDropdownItem>Another link</BSDropdownItem>
    </Content>
</BSDropdown>