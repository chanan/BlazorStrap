﻿<BSButton Color="BSColor.Primary" IsOutlined="true">Primary</BSButton>
<BSButton Color="BSColor.Secondary" IsOutlined="true">Primary</BSButton>
<BSButton Color="BSColor.Success" IsOutlined="true">Success</BSButton>
<BSButton Color="BSColor.Danger" IsOutlined="true">Danger</BSButton>
<BSButton Color="BSColor.Warning" IsOutlined="true">Warning</BSButton>
<BSButton Color="BSColor.Info" IsOutlined="true">Info</BSButton>
<BSButton Color="BSColor.Light" IsOutlined="true">Light</BSButton>
<BSButton Color="BSColor.Dark" IsOutlined="true">Dark</BSButton>