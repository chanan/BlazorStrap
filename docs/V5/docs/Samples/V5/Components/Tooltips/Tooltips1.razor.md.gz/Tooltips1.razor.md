﻿<BSButton Color="BSColor.Secondary" DataId="topTooltip">Tooltip on top</BSButton>
<BSTooltip Placement="Placement.Top" Target="topTooltip">Tooltip on top</BSTooltip>

<BSButton Color="BSColor.Secondary" DataId="rightTooltip">Tooltip on right</BSButton>
<BSTooltip Placement="Placement.Right" Target="rightTooltip">Tooltip on right</BSTooltip>

<BSButton Color="BSColor.Secondary" DataId="bottomTooltip">Tooltip on bottom</BSButton>
<BSTooltip Placement="Placement.Bottom" Target="bottomTooltip">Tooltip on bottom</BSTooltip>

<BSButton Color="BSColor.Secondary" DataId="leftTooltip">Tooltip on left</BSButton>
<BSTooltip Placement="Placement.Left" Target="leftTooltip">Tooltip on left</BSTooltip>

<BSButton Color="BSColor.Secondary" DataId="htmlTooltip">Tooltip with HTML</BSButton>
<BSTooltip Placement="Placement.Top" Target="htmlTooltip"><em>Tooltip</em> <u>with</u> <b>HTML</b></BSTooltip>