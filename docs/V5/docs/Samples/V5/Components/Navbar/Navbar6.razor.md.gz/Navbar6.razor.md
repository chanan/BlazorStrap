﻿<BSNavbar Color="BSColor.Light" IsFixedTop="true">
    <BSContainer Container="Container.Fluid">
        <BSNavbarBrand>Fixed top</BSNavbarBrand>
    </BSContainer>
</BSNavbar>