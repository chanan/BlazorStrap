﻿<BSAccordion>
    <BSAccordionItem>
        <Header>Accordion Item #1</Header>
        <Content>
            <strong>This is the first item's accordion body.</strong> It is shown by default. Placeholder content for this accordion.
        </Content>
    </BSAccordionItem>
    <BSAccordionItem>
        <Header>Accordion Item #2</Header>
        <Content>
            <strong>This is the second item's accordion body.</strong> It is hidden by default. Placeholder content for this accordion.
        </Content>
    </BSAccordionItem>
    <BSAccordionItem>
        <Header>Accordion Item #3</Header>
        <Content>
            <strong>This is the third item's accordion body.</strong> It is hidden by default. Placeholder content for this accordion.
        </Content>
    </BSAccordionItem>
</BSAccordion>