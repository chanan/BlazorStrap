﻿<BSLabel>Datalist example</BSLabel>
<BSInput InputType="InputType.DataList" list="datalistOptions" Value="@("Test")" />
<datalist id="datalistOptions">
    <option value="San Francisco"/>
    <option value="New York"/>
    <option value="Seattle"/>
    <option value="Los Angeles"/>
    <option value="Chicago"/>
</datalist>