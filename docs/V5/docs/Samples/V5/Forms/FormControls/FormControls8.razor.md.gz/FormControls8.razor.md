﻿<BSLabel>Color Picker</BSLabel>
<BSInput InputType="InputType.Color" Value="@("#563d7c")"/>