﻿<div Class="@BS.Form_Check">
    <BSInputCheckbox CheckedValue="@("nc")" Value="@("")" />
    <BSLabel IsCheckLabel="true">Default checkbox</BSLabel>
</div>
<div Class="@BS.Form_Check">
    <BSInputCheckbox CheckedValue="@("")" Value="@("")" />
    <BSLabel IsCheckLabel="true">Checked checkbox</BSLabel>
</div>