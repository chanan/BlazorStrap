﻿<BSInput InputType="InputType.Select" @bind-Value="_value" size="3">
    <option value="">Open this select menu</option>
    <option value="1">1</option>
    <option value="2">2</option>
    <option value="3">3</option>
</BSInput>
@string.Join(", ", _value)
@code{
    string[] _value = new string[]{};
}