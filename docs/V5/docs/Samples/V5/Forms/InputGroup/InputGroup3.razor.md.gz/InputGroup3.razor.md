﻿<BSInputGroup Size="Size.Small" MarginBottom="Margins.Medium">
    <span class="@BS.Input_Group_Text">Small</span>
    <BSInput InputType="InputType.Text" Value="@("")"/>
</BSInputGroup>

<BSInputGroup Size="Size.Medium" MarginBottom="Margins.Medium">
    <span class="@BS.Input_Group_Text">Medium</span>
    <BSInput InputType="InputType.Text" Value="@("")"/>
</BSInputGroup>

<BSInputGroup Size="Size.Large" MarginBottom="Margins.Medium">
    <span class="@BS.Input_Group_Text">Large</span>
    <BSInput InputType="InputType.Text" Value="@("")"/>
</BSInputGroup>