﻿<BSInputGroup MarginBottom="Margins.Medium">
    <BSDropdown>
        <Toggler><BSToggle IsButton="true" IsOutlined="true" Color="BSColor.Secondary">Dropdown</BSToggle></Toggler>
        <Content>
            <BSDropdownItem>Action</BSDropdownItem>
            <BSDropdownItem>Another action</BSDropdownItem>
            <BSDropdownItem>Something else here</BSDropdownItem>
            <BSDropdownItem IsDivider="true" />
            <BSDropdownItem>Separated link</BSDropdownItem>
        </Content>
    </BSDropdown>
    <BSInput InputType="InputType.Text"  Value="@("")"/>
</BSInputGroup>

<BSInputGroup MarginBottom="Margins.Medium">
    <BSInput InputType="InputType.Text"  Value="@("")"/>
    <BSDropdown Placement="Placement.BottomEnd">
        <Toggler><BSToggle IsButton="true" IsOutlined="true" Color="BSColor.Secondary">Dropdown</BSToggle></Toggler>
        <Content>
            <BSDropdownItem>Action</BSDropdownItem>
            <BSDropdownItem>Another action</BSDropdownItem>
            <BSDropdownItem>Something else here</BSDropdownItem>
            <BSDropdownItem IsDivider="true" />
            <BSDropdownItem>Separated link</BSDropdownItem>
        </Content>
    </BSDropdown>
</BSInputGroup>

<BSInputGroup MarginBottom="Margins.Medium">
    <BSDropdown>
        <Toggler><BSToggle IsButton="true" IsOutlined="true" Color="BSColor.Secondary">Dropdown</BSToggle></Toggler>
        <Content>
            <BSDropdownItem>Action before</BSDropdownItem>
            <BSDropdownItem>Another action before</BSDropdownItem>
            <BSDropdownItem>Something else here</BSDropdownItem>
            <BSDropdownItem IsDivider="true" />
            <BSDropdownItem>Separated link</BSDropdownItem>
        </Content>
    </BSDropdown>
    <BSInput InputType="InputType.Text"  Value="@("")"/>
    <BSDropdown Placement="Placement.BottomEnd">
        <Toggler><BSToggle IsButton="true" IsOutlined="true" Color="BSColor.Secondary">Dropdown</BSToggle></Toggler>
        <Content>
            <BSDropdownItem>Action</BSDropdownItem>
            <BSDropdownItem>Another action</BSDropdownItem>
            <BSDropdownItem>Something else here</BSDropdownItem>
            <BSDropdownItem IsDivider="true" />
            <BSDropdownItem>Separated link</BSDropdownItem>
        </Content>
    </BSDropdown>
</BSInputGroup>