﻿<h4>Nested Accordion inside of Acorddion</h4>
<BSButton Color="BSColor.Primary" OnClick="FirstTest">FirstTest</BSButton>
<BSAccordion>
    <BSAccordionItem DefaultShown="false" @ref="Test1">
        <Header>Editors</Header>
        <Content>
            <BSAccordion>
                <BSAccordionItem @ref="Test2">
                    <Header>Vehicles</Header>
                    <Content>
                        <NavLink class="nav-link" href="javascript:void(0)">
                            Test
                        </NavLink>
                        <NavLink class="nav-link" href="javascript:void(0)">
                            Test
                        </NavLink>
                        <NavLink class="nav-link" href="javascript:void(0)">
                            Test
                        </NavLink>
                        <NavLink class="nav-link" href="javascript:void(0)">
                            Test
                        </NavLink>
                        <NavLink class="nav-link" href="javascript:void(0)">
                            Test
                        </NavLink>
                        <NavLink class="nav-link" href="javascript:void(0)">
                            Test
                        </NavLink>
                    </Content>
                </BSAccordionItem>
            </BSAccordion>
            <NavLink class="nav-link" href="javascript:void(0)">
                Test
            </NavLink>
            <NavLink class="nav-link" href="javascript:void(0)">
                Test
            </NavLink>
            <NavLink class="nav-link" href="javascript:void(0)">
                Test
            </NavLink>
            <NavLink class="nav-link" href="javascript:void(0)">
                Test
            </NavLink>
            <NavLink class="nav-link" href="javascript:void(0)">
                Test
            </NavLink>
            <NavLink class="nav-link" href="javascript:void(0)">
                Test
            </NavLink>
        </Content>
    </BSAccordionItem>
</BSAccordion>

<h4>Nested Accordion inside of Collapse</h4>
<hr />
<BSButton Color="BSColor.Primary" OnClick="SecondTest">SecondTest</BSButton>
<BSCollapse @ref="Test3">
    <Toggler><BSToggle>Test</BSToggle></Toggler>
    <Content>
        <BSAccordion>
            <BSAccordionItem @ref="Test4">
                <Header>Vehicles</Header>
                <Content>
                    <NavLink class="nav-link" href="javascript:void(0)">
                        Test
                    </NavLink>
                </Content>
            </BSAccordionItem>
        </BSAccordion>
    </Content>
</BSCollapse>

<h4>Nested Collapse inside of Collapse</h4>
<hr />
<BSButton Color="BSColor.Primary" OnClick="ThirdTest">ThirdTest</BSButton>
<BSCollapse @ref="Test5">
    <Toggler><BSToggle>Toggle Test</BSToggle></Toggler>
    <Content>
        <BSCollapse @ref="Test6">
            <Toggler><BSToggle>Toggle Test</BSToggle></Toggler>
            <Content>
                <NavLink class="nav-link" href="javascript:void(0)">
                    Test
                </NavLink>
            </Content>
        </BSCollapse>
    </Content>
</BSCollapse>

<h4>Nested Collapse inside of Acorddion</h4>
<hr />
<BSButton Color="BSColor.Primary" OnClick="ForthTest">ForthTest</BSButton>
<BSAccordion>
    <BSAccordionItem DefaultShown="false" @ref="Test7">
        <Header>Test</Header>
        <Content>
            <BSCollapse @ref="Test8">
                <Toggler><BSToggle>Toggle Test</BSToggle></Toggler>
                <Content>
                    <NavLink class="nav-link" href="javascript:void(0)">
                        Test
                    </NavLink>
                </Content>
            </BSCollapse>
        </Content>
    </BSAccordionItem>
</BSAccordion>
<h4>Nested Collapse inside of Acorddion in side of Collapse Plus StateHasChanged tossed in for good messure</h4>
<hr />
<BSButton Color="BSColor.Primary" OnClick="FifthTest">FifthTest</BSButton>
<BSCollapse @ref="Test9">
    <Toggler><BSToggle>Toggle Test</BSToggle></Toggler>
    <Content>

        <BSAccordion>
            <BSAccordionItem DefaultShown="false" @ref="Test10">
                <Header>Test</Header>
                <Content>
                    <BSCollapse @ref="Test11">
                        <Toggler><BSToggle>Toggle Test</BSToggle></Toggler>
                        <Content>
                            <NavLink class="nav-link" href="javascript:void(0)">
                                Test
                            </NavLink>
                        </Content>
                    </BSCollapse>
                </Content>
            </BSAccordionItem>
        </BSAccordion>
    </Content>
</BSCollapse>
@code {
    private BSAccordionItem Test1 { get; set; }
    private BSAccordionItem Test2 { get; set; }
    private BSCollapse Test3 { get; set; }
    private BSAccordionItem Test4 { get; set; }
    private BSCollapse Test5 { get; set; }
    private BSCollapse Test6 { get; set; }
    private BSAccordionItem Test7 { get; set; }
    private BSCollapse Test8 { get; set; }
    private BSCollapse Test9 { get; set; }
    private BSAccordionItem Test10 { get; set; }
    private BSCollapse Test11 { get; set; }
    private async Task FirstTest()
    {
        await Test2.HideAsync();
        await Task.Delay(2);
        _ = Test1.HideAsync();
        await InvokeAsync(StateHasChanged);
    }

    private async Task SecondTest()
    {
        await Test4.HideAsync();
        await Task.Delay(2);
        _ = Test3.HideAsync();
        await InvokeAsync(StateHasChanged);
    }
    private async Task ThirdTest()
    {
        await Test6.HideAsync();
        await Task.Delay(2);
        _ = Test5.HideAsync();
        await InvokeAsync(StateHasChanged);
    }

    private async Task ForthTest()
    {
        await Test8.HideAsync();
        await Task.Delay(2);
        _ = Test7.HideAsync();
        await InvokeAsync(StateHasChanged);
    }
    private async Task FifthTest()
    {
        await Test11.HideAsync();
        await Task.Delay(2);
        await Test10.HideAsync();
        await Task.Delay(2);
        _ = Test9.HideAsync();
        await InvokeAsync(StateHasChanged);
    }
}
