﻿<BSContainer>
    <BSRow>
        <BSCol ColumnSmall="5" ColumnMedium="6">ColumnSmall="5" ColumnMedium="6"</BSCol>
        <BSCol ColumnSmall="5" OffsetSmall="2" ColumnMedium="6" OffsetMedium="0">ColumnSmall="5" OffsetSmall="2" ColumnMedium="6" OffsetMedium="0"</BSCol>
    </BSRow>
    <BSRow>
        <BSCol ColumnSmall="6" ColumnMedium="5" ColumnLarge="6">ColumnSmall="6" ColumnMedium="5" ColumnLarge="6"</BSCol>
        <BSCol ColumnSmall="6" ColumnMedium="5" OffsetMedium="2" ColumnLarge="6" OffsetLarge="0">ColumnSmall="6" ColumnMedium="5" OffsetMedium="2" ColumnLarge="6" OffsetLarge="0"</BSCol>
    </BSRow>
</BSContainer> 