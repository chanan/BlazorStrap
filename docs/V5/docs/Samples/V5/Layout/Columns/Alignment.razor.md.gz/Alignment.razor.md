﻿<BSContainer>
    <BSRow Align="Align.Start">
        <BSCol>
            One of three columns
        </BSCol>
        <BSCol>
            One of three columns
        </BSCol>
        <BSCol>
            One of three columns
        </BSCol>
    </BSRow>
    <BSRow Align="Align.Center">
        <BSCol>
            One of three columns
        </BSCol>
        <BSCol>
            One of three columns
        </BSCol>
        <BSCol>
            One of three columns
        </BSCol>
    </BSRow>
    <BSRow Align="Align.End">
        <BSCol>
            One of three columns
        </BSCol>
        <BSCol>
            One of three columns
        </BSCol>
        <BSCol>
            One of three columns
        </BSCol>
    </BSRow>
</BSContainer>