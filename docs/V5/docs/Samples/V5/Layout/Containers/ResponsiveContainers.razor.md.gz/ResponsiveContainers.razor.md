﻿<BSContainer Container="Container.Small">100% wide until small breakpoint</BSContainer>
<BSContainer Container="Container.Medium">100% wide until medium breakpoint</BSContainer>
<BSContainer Container="Container.Large">100% wide until large breakpoint</BSContainer>
<BSContainer Container="Container.ExrtaLarge">100% wide until extra large breakpoint</BSContainer>
<BSContainer Container="Container.ExtraExtraLarge">100% wide until extra extra large breakpoint</BSContainer>