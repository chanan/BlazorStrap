﻿<BSContainer Container="Container.Fluid">
    <!-- Content here -->
</BSContainer>