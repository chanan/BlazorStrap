﻿<BSImage Source="200x200" IsRounded="true" IsPlaceholder="true"  Align="Align.Center" />
