﻿<BSImage Source="200x200" IsRounded="true" IsPlaceholder="true" Align="Align.Start"/>
<BSImage Source="200x200" IsRounded="true" IsThumbnail="true"  IsPlaceholder="true"  Align="Align.End"/>