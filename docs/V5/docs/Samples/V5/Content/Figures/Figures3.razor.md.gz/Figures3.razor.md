﻿<BSFigure>
    <BSSvg Source="docs/FigurePlaceHolder.svg"/>
    <BSFigureCaption>SVG Loader</BSFigureCaption>
</BSFigure>