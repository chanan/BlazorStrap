﻿<BSContainer>
    <BSRow>
        <BSCol Column="6" ColumnSmall="3">Column="6" ColumnSmall="3"</BSCol>
        <BSCol Column="6" ColumnSmall="3">Column="6" ColumnSmall="3"</BSCol>
         <!-- Force next columns to break to new line at md breakpoint and up -->
        <BSColBreak/>
        <BSCol Column="6" ColumnSmall="3">Column="6" ColumnSmall="3"</BSCol>
        <BSCol Column="6" ColumnSmall="3">Column="6" ColumnSmall="3"</BSCol>
    </BSRow>
</BSContainer> 