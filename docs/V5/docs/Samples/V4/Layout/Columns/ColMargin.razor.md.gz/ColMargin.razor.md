﻿<BSContainer>
    <BSRow>
        <BSCol ColumnMedium="4">ColumnMedium="4"</BSCol>
        <BSCol ColumnMedium="4" MarginStart="Margins.Auto">ColumnMedium="4" MarginStart="Margins.Auto"</BSCol>
    </BSRow>
    <BSRow>
        <BSCol ColumnMedium="3" Class="ms-md-auto">ColumnMedium="3" Class="ms-md-auto"</BSCol>
        <BSCol ColumnMedium="3" Class="ms-md-auto">ColumnMedium="3" Class="ms-md-auto"</BSCol>
    </BSRow>
    <BSRow>
        <BSCol Auto="true" MarginEnd="Margins.Auto">Auto="true" MarginEnd="Margins.Auto"</BSCol>
        <BSCol Auto="true">Auto="true"</BSCol>
    </BSRow>
</BSContainer>