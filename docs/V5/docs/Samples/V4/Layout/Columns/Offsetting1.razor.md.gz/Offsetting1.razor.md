﻿<BSContainer>
    <BSRow>
        <BSCol ColumnMedium="4">ColumnMedium="4"</BSCol>
        <BSCol ColumnMedium="4" OffsetMedium="4">ColumnMedium="4" OffsetMedium="4"</BSCol>
    </BSRow>
    <BSRow>
        <BSCol ColumnMedium="3" OffsetMedium="3">ColumnMedium="3" OffsetMedium="3"</BSCol>
        <BSCol ColumnMedium="3" OffsetMedium="3">ColumnMedium="3" OffsetMedium="3"</BSCol>
    </BSRow>
    <BSRow>
        <BSCol ColumnMedium="6" OffsetMedium="3">ColumnMedium="6" OffsetMedium="3"</BSCol>
    </BSRow>
</BSContainer>