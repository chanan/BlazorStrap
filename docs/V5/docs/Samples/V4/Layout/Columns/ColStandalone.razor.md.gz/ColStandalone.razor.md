﻿<BSCol Column="3" Class="bg-light border" Padding="Padding.Medium">
    Column 3: width of 25%
</BSCol>
<BSCol ColumnSmall="9" Class="bg-light border" Padding="Padding.Medium">
    Column Small 9: width of 75% above sm breakpoint
</BSCol>