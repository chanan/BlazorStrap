﻿<BSContainer>
    <BSRow>
        <BSCol>
            First in DOM, no order applied
        </BSCol>
        <BSCol Order="5">
            Second in DOM, with a larger order
        </BSCol>
        <BSCol Order="1">
            Third in DOM, with an order of 1
        </BSCol>
    </BSRow>
</BSContainer>