﻿<BSProgress>
    <BSProgressBar IsStriped="true" Color="BSColor.Primary" Value="15"></BSProgressBar>
    <BSProgressBar IsStriped="true" Color="BSColor.Danger" Value="20"></BSProgressBar>
    <BSProgressBar IsStriped="true" Color="BSColor.Success" Value="10"></BSProgressBar>
    <BSProgressBar IsStriped="true" Color="BSColor.Warning" Value="5"></BSProgressBar>
</BSProgress>