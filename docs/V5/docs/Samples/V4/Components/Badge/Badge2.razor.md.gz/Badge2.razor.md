﻿<BSButton Color="BSColor.Primary">
    Notifications <BSBadge Color="BSColor.Secondary">4</BSBadge>
</BSButton>