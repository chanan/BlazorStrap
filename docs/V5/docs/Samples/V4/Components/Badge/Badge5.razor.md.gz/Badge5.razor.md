﻿<BSBadge Color="BSColor.Primary">Primary</BSBadge>
<BSBadge Color="BSColor.Secondary">Secondary</BSBadge>
<BSBadge Color="BSColor.Success">Success</BSBadge>
<BSBadge Color="BSColor.Danger">Danger</BSBadge>
<BSBadge Color="BSColor.Warning" Class="text-dark">Warning</BSBadge>
<BSBadge Color="BSColor.Info" Class="text-dark">Info</BSBadge>
<BSBadge Color="BSColor.Light" Class="text-dark">Light</BSBadge>
<BSBadge Color="BSColor.Dark">Dark</BSBadge>