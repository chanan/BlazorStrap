﻿<BSNavbar Color="BSColor.Dark" IsDark="true">
    <BSContainer Container="Container.Fluid">
        <BSNavbarBrand>Navbar</BSNavbarBrand>
    </BSContainer>
</BSNavbar>
<BSNavbar Color="BSColor.Primary" IsDark="true">
    <BSContainer Container="Container.Fluid">
        <BSNavbarBrand>Navbar</BSNavbarBrand>
    </BSContainer>
</BSNavbar>
<BSNavbar Color="BSColor.Light">
    <BSContainer Container="Container.Fluid">
        <BSNavbarBrand>Navbar</BSNavbarBrand>
    </BSContainer>
</BSNavbar>