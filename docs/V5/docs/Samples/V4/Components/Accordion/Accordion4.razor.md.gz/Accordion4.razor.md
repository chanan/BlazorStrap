<BSAccordion>
    <BSAccordionItem DefaultShown="false">
        <Header>Accordion Item #1</Header>
        <Content>
            Placeholder content for this accordion, which is intended to demonstrate the DefaultShown parameter. This is the first item's accordion body.
        </Content>
    </BSAccordionItem>
    <BSAccordionItem>
        <Header>Accordion Item #2</Header>
        <Content>
            Placeholder content for the second accordion.
        </Content>
    </BSAccordionItem>
    <BSAccordionItem>
        <Header>Accordion Item #3</Header>
        <Content>
            Placeholder content for third accordion.
        </Content>
    </BSAccordionItem>
</BSAccordion>