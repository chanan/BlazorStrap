﻿<BSAccordion IsFlushed="true">
    <BSAccordionItem>
        <Header>Accordion Item #1</Header>
        <Content>
            Placeholder content for this accordion, which is intended to demonstrate the IsFlushed parameter. 
        </Content>
    </BSAccordionItem>
    <BSAccordionItem>
        <Header>Accordion Item #2</Header>
        <Content>
            Placeholder content for this accordion, which is intended to demonstrate the IsFlushed parameter.
        </Content>
    </BSAccordionItem>
    <BSAccordionItem>
        <Header>Accordion Item #3</Header>
        <Content>
            Placeholder content for this accordion, which is intended to demonstrate the IsFlushed parameter. 
        </Content>
    </BSAccordionItem>
</BSAccordion>