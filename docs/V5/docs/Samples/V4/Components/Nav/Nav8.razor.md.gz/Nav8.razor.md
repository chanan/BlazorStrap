﻿<BSNav IsPills="true">
    <BSNavItem IsActive="true">Active</BSNavItem>
    <BSNavItem>Link</BSNavItem>
    <BSNavItem>Link</BSNavItem>
    <BSNavItem IsDisabled="true">Disabled</BSNavItem>
</BSNav>