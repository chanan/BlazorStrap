﻿<BSNav IsTabs="true" @ref="_method1"> 
    <BSNavItem DataId="Tab1">Tab1</BSNavItem>
    <BSNavItem @ref="_method2">Tab2</BSNavItem>
    <BSNavItem DataId="Tab3">Tab3</BSNavItem>
</BSNav>

<BSButton OnClick="Method1">Set Active Tab between 1 and 3</BSButton>
<BSButton OnClick="Method2">Invoke Tab2</BSButton>
@code{
    private BSNav _method1 = new BSNav();
    private BSNavItem _method2 = new BSNavItem();

    private void Method1()
    {
        if(_method1.ActiveChild?.DataId == "Tab1")
        {
            _method1.SetActiveTab("Tab3");
        }
        else
        {
            _method1.SetActiveTab("Tab1");
        }
    }
    private void Method2()
    {
        _method2.Invoke();
    }
}