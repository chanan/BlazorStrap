﻿<BSNav IsTabs="true">
    <BSNavItem>Active</BSNavItem>
    <BSNavItem>Link</BSNavItem>
    <BSNavItem>Link</BSNavItem>
    <BSNavItem IsDisabled="true">Disabled</BSNavItem>
</BSNav>