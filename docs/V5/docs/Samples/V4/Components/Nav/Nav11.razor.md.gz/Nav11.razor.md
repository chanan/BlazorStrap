﻿<BSNav IsNav="true" IsPills="true" IsVertical="true" Class="flex-sm-row" >
    <BSNavItem Class="flex-sm-fill text-sm-center" IsActive="true">Active</BSNavItem>
    <BSNavItem Class="flex-sm-fill text-sm-center">Link</BSNavItem>
    <BSNavItem Class="flex-sm-fill text-sm-center">Link</BSNavItem>
    <BSNavItem Class="flex-sm-fill text-sm-center" IsDisabled="true">Disabled</BSNavItem>
</BSNav>