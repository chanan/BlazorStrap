﻿<BSModal DataId="modal8a" Size="Size.ExtraLarge">
    <Header>Extra Large Demo</Header>
    <Content>Demo Modal</Content>
        <Footer Context="modal">
            <BSButton MarginStart="Margins.Auto" Color="BSColor.Secondary" @onclick="modal.HideAsync">Close</BSButton>
            <BSButton Color="BSColor.Primary">Understood</BSButton>
        </Footer>
</BSModal>
<BSModal DataId="modal8b" Size="Size.Large">
    <Header>Large Demo</Header>
    <Content>Demo Modal</Content>
        <Footer Context="modal">
            <BSButton MarginStart="Margins.Auto" Color="BSColor.Secondary" @onclick="modal.HideAsync">Close</BSButton>
            <BSButton Color="BSColor.Primary">Understood</BSButton>
        </Footer>
</BSModal>
<BSModal DataId="modal8c" Size="Size.Small">
    <Header>Small Demo</Header>
    <Content>Demo Modal</Content>
        <Footer Context="modal">
            <BSButton MarginStart="Margins.Auto" Color="BSColor.Secondary" @onclick="modal.HideAsync">Close</BSButton>
            <BSButton Color="BSColor.Primary">Understood</BSButton>
        </Footer>
</BSModal>

<BSButton Color="BSColor.Primary" Target="modal8a">Extra large modal</BSButton>
<BSButton Color="BSColor.Primary" Target="modal8b">Large modal</BSButton>
<BSButton Color="BSColor.Primary" Target="modal8c">Small modal</BSButton>