﻿<BSToast Color="BSColor.Success" HasIcon="true">
    <Header><strong>BlazorStarp</strong></Header>
    <Content>Hello, world!</Content>
</BSToast>