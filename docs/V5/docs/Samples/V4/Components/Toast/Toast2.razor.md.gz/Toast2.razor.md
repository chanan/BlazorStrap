﻿<BSToast Color="BSColor.Success" HasIcon="true">
    <Content>Hello, world!</Content>
</BSToast>