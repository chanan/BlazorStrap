<BSButtonGroup>
    <BSDropdown>
        <Toggler>
            <BSToggle IsButton="true" Color="BSColor.Secondary">Dropdown</BSToggle>
        </Toggler>
        <Content>
            <BSDropdownItem IsButton="true">Action</BSDropdownItem>
            <BSDropdownItem IsButton="true">Another action</BSDropdownItem>
            <BSDropdownItem IsButton="true">Something else here</BSDropdownItem>
        </Content>
    </BSDropdown>
</BSButtonGroup>
<BSButtonGroup DropdownPlacement="Placement.BottomEnd">
    <BSDropdown>
        <Toggler>
            <BSToggle IsButton="true" Color="BSColor.Secondary">Right-aligned menu</BSToggle>
        </Toggler>
        <Content>
            <BSDropdownItem IsButton="true">Action</BSDropdownItem>
            <BSDropdownItem IsButton="true">Another action</BSDropdownItem>
            <BSDropdownItem IsButton="true">Something else here</BSDropdownItem>
        </Content>
    </BSDropdown>
</BSButtonGroup>
<BSButtonGroup>
    <BSDropdown IsStatic="true" Class="dropdown-menu-lg-end">
        <Toggler>
            <BSToggle IsButton="true" Color="BSColor.Secondary">Left-aligned,right-aligned lg</BSToggle>
        </Toggler>
        <Content>
            <BSDropdownItem IsButton="true">Action</BSDropdownItem>
            <BSDropdownItem IsButton="true">Another action</BSDropdownItem>
            <BSDropdownItem IsButton="true">Something else here</BSDropdownItem>
        </Content>
    </BSDropdown>
</BSButtonGroup>
<BSButtonGroup>
    <BSDropdown IsStatic="true" Class="dropdown-menu-end dropdown-menu-lg-start">
        <Toggler>
            <BSToggle IsButton="true" Color="BSColor.Secondary">Right-aligned, left-aligned lg</BSToggle>
        </Toggler>
        <Content>
            <BSDropdownItem IsButton="true">Action</BSDropdownItem>
            <BSDropdownItem IsButton="true">Another action</BSDropdownItem>
            <BSDropdownItem IsButton="true">Something else here</BSDropdownItem>
        </Content>
    </BSDropdown>
</BSButtonGroup>
<BSButtonGroup DropdownPlacement="Placement.LeftStart">
    <BSDropdown>
        <Toggler>
            <BSToggle IsButton="true" Color="BSColor.Secondary">Dropstart</BSToggle>
        </Toggler>
        <Content>
            <BSDropdownItem IsButton="true">Action</BSDropdownItem>
            <BSDropdownItem IsButton="true">Another action</BSDropdownItem>
            <BSDropdownItem IsButton="true">Something else here</BSDropdownItem>
        </Content>
    </BSDropdown>
</BSButtonGroup>
<BSButtonGroup DropdownPlacement="Placement.RightStart">
    <BSDropdown>
        <Toggler>
            <BSToggle IsButton="true" Color="BSColor.Secondary">Dropend</BSToggle>
        </Toggler>
        <Content>
            <BSDropdownItem IsButton="true">Action</BSDropdownItem>
            <BSDropdownItem IsButton="true">Another action</BSDropdownItem>
            <BSDropdownItem IsButton="true">Something else here</BSDropdownItem>
        </Content>
    </BSDropdown>
</BSButtonGroup>
<BSButtonGroup DropdownPlacement="Placement.TopStart">
    <BSDropdown>
        <Toggler>
            <BSToggle IsButton="true" Color="BSColor.Secondary">Dropup</BSToggle>
        </Toggler>
        <Content>
            <BSDropdownItem IsButton="true">Action</BSDropdownItem>
            <BSDropdownItem IsButton="true">Another action</BSDropdownItem>
            <BSDropdownItem IsButton="true">Something else here</BSDropdownItem>
        </Content>
    </BSDropdown>
</BSButtonGroup>