<BSDropdown Demo="true">
    <Content>
        <BSDropdownItem>Action</BSDropdownItem>
        <BSDropdownItem>Another action</BSDropdownItem>
        <BSDropdownItem>Shomething else here</BSDropdownItem>
        <BSDropdownItem IsDivider="true"/>
        <BSDropdownItem>Separated link</BSDropdownItem>
    </Content>
</BSDropdown>