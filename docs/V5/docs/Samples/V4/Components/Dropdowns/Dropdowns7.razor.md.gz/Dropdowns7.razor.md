<BSDropdown IsDark="true">
    <Toggler>
        <BSToggle IsButton="true" Color="BSColor.Secondary">Dropdown Button</BSToggle>
    </Toggler>
    <Content>
        <BSDropdownItem>Action</BSDropdownItem>
        <BSDropdownItem>Another action</BSDropdownItem>
        <BSDropdownItem>Something else here</BSDropdownItem>
        <BSDropdownItem IsDivider="true"/>
        <BSDropdownItem>Separated link</BSDropdownItem>
    </Content>
</BSDropdown>