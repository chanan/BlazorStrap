<!--\\-->
<BSButtonGroup>
    <BSDropdown>
        <Toggler>
            <BSToggle IsButton="true" Color="BSColor.Primary">Primary</BSToggle>
        </Toggler>
        <Content>
            <BSDropdownItem>Action</BSDropdownItem>
            <BSDropdownItem>Another action</BSDropdownItem>
            <BSDropdownItem>Something else here</BSDropdownItem>
        </Content>
    </BSDropdown>
</BSButtonGroup>
<BSButtonGroup>
    <BSDropdown>
        <Toggler>
            <BSToggle IsButton="true" Color="BSColor.Secondary">Secondary</BSToggle>
        </Toggler>
        <Content>
            <BSDropdownItem>Action</BSDropdownItem>
            <BSDropdownItem>Another action</BSDropdownItem>
            <BSDropdownItem>Something else here</BSDropdownItem>
        </Content>
    </BSDropdown>
</BSButtonGroup>
<BSButtonGroup>
    <BSDropdown>
        <Toggler>
            <BSToggle IsButton="true" Color="BSColor.Success">Success</BSToggle>
        </Toggler>
        <Content>
            <BSDropdownItem>Action</BSDropdownItem>
            <BSDropdownItem>Another action</BSDropdownItem>
            <BSDropdownItem>Something else here</BSDropdownItem>
        </Content>
    </BSDropdown>
</BSButtonGroup>
<BSButtonGroup>
    <BSDropdown>
        <Toggler>
            <BSToggle IsButton="true" Color="BSColor.Info">Info</BSToggle>
        </Toggler>
        <Content>
            <BSDropdownItem>Action</BSDropdownItem>
            <BSDropdownItem>Another action</BSDropdownItem>
            <BSDropdownItem>Something else here</BSDropdownItem>
        </Content>
    </BSDropdown>
</BSButtonGroup>
<BSButtonGroup>
    <BSDropdown>
        <Toggler>
            <BSToggle IsButton="true" Color="BSColor.Warning">Warning</BSToggle>
        </Toggler>
        <Content>
            <BSDropdownItem>Action</BSDropdownItem>
            <BSDropdownItem>Another action</BSDropdownItem>
            <BSDropdownItem>Something else here</BSDropdownItem>
        </Content>
    </BSDropdown>
</BSButtonGroup>
<!--//-->
<!-- Example Danger button -->
<BSButtonGroup>
    <BSDropdown>
        <Toggler>
            <BSToggle IsButton="true" Color="BSColor.Danger">Danger</BSToggle>
        </Toggler>
        <Content>
            <BSDropdownItem>Action</BSDropdownItem>
            <BSDropdownItem>Another action</BSDropdownItem>
            <BSDropdownItem>Something else here</BSDropdownItem>
        </Content>
    </BSDropdown>
</BSButtonGroup>

