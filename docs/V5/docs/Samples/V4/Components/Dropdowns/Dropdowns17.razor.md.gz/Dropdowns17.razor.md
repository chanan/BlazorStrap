<BSButtonGroup>
    <BSDropdown IsStatic="true" Class="dropdown-menu-lg-end">
        <Toggler>
            <BSToggle IsButton="true" Color="BSColor.Secondary">Left-aligned but right aligned when large screen</BSToggle>
        </Toggler>
        <Content>
            <BSDropdownItem IsButton="true">Action</BSDropdownItem>
            <BSDropdownItem IsButton="true">Another action</BSDropdownItem>
            <BSDropdownItem IsButton="true">Something else here</BSDropdownItem>
        </Content>
    </BSDropdown>
</BSButtonGroup>