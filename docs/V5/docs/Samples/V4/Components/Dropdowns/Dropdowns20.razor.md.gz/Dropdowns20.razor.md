<BSDropdown Demo="true">
    <Content>
        <BSDropdownItem Header="6">Dropdown header</BSDropdownItem>
        <BSDropdownItem>Action</BSDropdownItem>
        <BSDropdownItem>Another action</BSDropdownItem>
    </Content>
</BSDropdown>