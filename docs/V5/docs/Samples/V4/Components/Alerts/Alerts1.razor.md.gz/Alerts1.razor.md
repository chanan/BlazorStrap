﻿<BSAlert Color="BSColor.Primary">A simple primary alert—check it out!</BSAlert>
<BSAlert Color="BSColor.Secondary">A simple secondary alert—check it out!</BSAlert>
<BSAlert Color="BSColor.Success">A simple success alert—check it out!</BSAlert>
<BSAlert Color="BSColor.Danger">A simple danger alert—check it out!</BSAlert>
<BSAlert Color="BSColor.Warning">A simple warning alert—check it out!</BSAlert>
<BSAlert Color="BSColor.Info">A simple info alert—check it out!</BSAlert>
<BSAlert Color="BSColor.Light">A simple light alert—check it out!</BSAlert>
<BSAlert Color="BSColor.Dark">A simple dark alert—check it out!</BSAlert>
