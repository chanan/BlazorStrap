﻿<BSAlert Color="BSColor.Info" HasIcon="true">
    An example alert with an icon
</BSAlert>
<BSAlert Color="BSColor.Success" HasIcon="true">
    An example alert with an icon
</BSAlert>
<BSAlert Color="BSColor.Warning" HasIcon="true">
    An example alert with an icon
</BSAlert>
<BSAlert Color="BSColor.Danger" HasIcon="true">
    An example alert with an icon
</BSAlert>