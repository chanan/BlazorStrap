<BSSpinner Color="BSColor.Primary"/>
<BSSpinner Color="BSColor.Secondary"/>
<BSSpinner Color="BSColor.Success"/>
<BSSpinner Color="BSColor.Danger"/>
<BSSpinner Color="BSColor.Warning"/>
<BSSpinner Color="BSColor.Info"/>
<BSSpinner Color="BSColor.Light"/>
<BSSpinner Color="BSColor.Dark"/>