﻿<BSCard CardType="CardType.Card" style="width: 18rem;">
    <BSCard CardType="CardType.Image" src="placeholder:286x180" alt="Card image cap"/>
    <BSCard CardType="CardType.Body">
        <BSCard CardType="CardType.Title">Card title</BSCard>
        <BSCard CardType="CardType.Text">
            Some quick example text to build on the card title and make up the bulk of the card's content
        </BSCard>
        <BSButton Color="BSColor.Primary">Go Somewhere</BSButton>
    </BSCard>
</BSCard>