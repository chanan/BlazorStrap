﻿<BSLink href="javascript:void(0)" IsButton="true" Color="BSColor.Primary">Primary</BSLink>
<BSLink href="javascript:void(0)" IsButton="true" Color="BSColor.Secondary">Primary</BSLink>
<BSLink href="javascript:void(0)" IsButton="true" Color="BSColor.Success">Success</BSLink>
<BSLink href="javascript:void(0)" IsButton="true" Color="BSColor.Danger">Danger</BSLink>
<BSLink href="javascript:void(0)" IsButton="true" Color="BSColor.Warning">Warning</BSLink>
<BSLink href="javascript:void(0)" IsButton="true" Color="BSColor.Info">Info</BSLink>
<BSLink href="javascript:void(0)" IsButton="true" Color="BSColor.Light">Light</BSLink>
<BSLink href="javascript:void(0)" IsButton="true" Color="BSColor.Dark">Dark</BSLink>
<BSLink href="javascript:void(0)">Normal Link</BSLink>