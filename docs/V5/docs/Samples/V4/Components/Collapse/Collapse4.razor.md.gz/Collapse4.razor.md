﻿<p>
    <BSButton Target="collapse4" Color="BSColor.Primary">Toggle horizontal collapse</BSButton>
</p>
<div style="min-height: 120px;">
    <BSCollapse IsHorizontal="true" DataId="collapse4">
        <div class="card card-body" style="width: 300px;">
            This is some placeholder content for a horizontal collapse. It's hidden by default and shown when triggered.
        </div>
    </BSCollapse>
    <div class="collapse collapse-horizontal" id="collapseWidthExample">
    </div>
</div>