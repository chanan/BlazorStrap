﻿<BSTable IsResponsive="true" IsStriped="true">
    <BSTHead>
        <BSTR>
            <BSTD>#</BSTD>
            <BSTD>First</BSTD>
            <BSTD>Last</BSTD>
            <BSTD>Handle</BSTD>
        </BSTR>
    </BSTHead>
    <BSTBody>
        <BSTR>
            <BSTD>1</BSTD>
            <BSTD>John</BSTD>
            <BSTD>Doe</BSTD>
            <BSTD>JohnDoe <br/>media.com</BSTD>
        </BSTR>
        <BSTR>
            <BSTD>2</BSTD>
            <BSTD>Jane</BSTD>
            <BSTD>Doe</BSTD>
            <BSTD>JaneDoe <br/>media.com</BSTD>
        </BSTR>
    </BSTBody>
    <BSTFoot>
        <BSTR>
            <BSTD ColSpan="4">Spanned Table Footer Here</BSTD>
        </BSTR>

    </BSTFoot>
</BSTable>