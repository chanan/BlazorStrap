﻿<BSLabel>Example range @Value</BSLabel>
<BSInput InputType="InputType.Range" @bind-Value="Value" min="0" max="5"/>
@code {
    private int Value { get; set; }
}