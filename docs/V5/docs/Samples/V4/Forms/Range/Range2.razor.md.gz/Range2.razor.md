﻿<BSLabel>Disabled range</BSLabel>
<BSInput InputType="InputType.Range" @bind-Value="Value" IsDisabled="true"/>
@code {
    private int Value { get; set; }
}