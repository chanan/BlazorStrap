﻿<div class="mb-3">
    <BSLabel>Email address</BSLabel>
    <BSInput InputType="InputType.Email" placeholder="name@example.com" Value="@("")"/>
</div>
<div class="mb-3">
    <BSLabel>Example Textarea</BSLabel>
    <BSInput InputType="InputType.TextArea" Value="@("")"/>
</div>