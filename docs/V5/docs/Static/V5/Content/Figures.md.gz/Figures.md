﻿## Figures
#### Component \<BSFigure\> \<BSFigureCaption\>
See [shared](layout/shared) for parameters    

{{sample=V5/Content/Figures/Figures1}}

{{sample=V5/Content/Figures/Figures2}}

{{sample=V5/Content/Figures/Figures3}}